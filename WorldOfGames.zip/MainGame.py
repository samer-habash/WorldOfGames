import Live

print(Live.welcome("Guy"))
Live.load_game()
