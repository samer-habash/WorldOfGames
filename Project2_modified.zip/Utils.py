
SCORES_FILE_NAME = "Scores.txt"


#return error for a funtion is -1
BAD_RETURN_CODE = -1

def Screen_cleaner():
    print("\033[H\033[J")

