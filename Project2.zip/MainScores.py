from flask import Flask, render_template
from Utils import SCORES_FILE_NAME

app = Flask(__name__)

@app.route("/Score", methods=['GET', 'POST'])
def score_server():
    with open(SCORES_FILE_NAME, 'r') as f:
        if os.path.exists(SCORES_FILE_NAME) and os.path.getsize(SCORES_FILE_NAME) > 0:
            SCORE = f.readlines()
            return """
            <html>
            <head>
                <title>Scores Game</title>
            </head>
            <body>
                <h1>The score is <div id="score">{{ SCORE }}</div></h1>
            </body>
            </html>
            """
        else:
            ERROR = "Error Occurred 404"
            return """
            <html>
            <head>
                <title>Scores Game</title>
            </head>
            <body>
                <h1><div id="score" style="color:red">{{ ERROR }}</div></h1>
            </body>
            </html>
            """"

if __name__ == "__main__":
    app.run()
